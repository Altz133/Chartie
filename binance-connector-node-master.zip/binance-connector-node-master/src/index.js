module.exports.Spot = require('./spot')
