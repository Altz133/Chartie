class Error {
  constructor (message) {
    this.message = message
    this.name = 'Error'
  }
}

module.exports = Error
