<template>
  <main class="w-50 mx-auto">
    <div class="p-5 text-center">
      <h1 class="mb-5">Page Not Found</h1>
      <p class="lead">The page you're looking for can't be found. Looks like you've followed a broken link or entered a URL that doesn't exist on this site.</p>
    </div>
  </main>
</template>

<script>
export default {
  name: '404'
}
</script>
